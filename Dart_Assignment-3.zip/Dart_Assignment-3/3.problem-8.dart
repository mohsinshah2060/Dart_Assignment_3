// 3.problem-8 Function to Add Two Numbers**

int add(int a, int b) {
  int result = a + b;
  return result;
}

void main() {
  int b = add(50, 50);
  print(b);
}

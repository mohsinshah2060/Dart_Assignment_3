//3.problem-5 Area of Circle Using Function**
void area_of_cicle(double r) {
  double area = 3.1416 * r * r;
  print(area);
}

void main() {
  double radius = 10.3;
  area_of_cicle(radius);
}

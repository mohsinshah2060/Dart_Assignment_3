//3.problem-1 Print MY Name Using Function

void myname() {
  print("Mohsin Shah");
}

void main() {
  myname();
}

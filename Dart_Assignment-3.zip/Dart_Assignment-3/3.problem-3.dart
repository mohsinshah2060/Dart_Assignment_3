//3.problem-3 Greet Function

void greet(String name) {
  print("Hello, My friend $name");
}

void main() {
  greet("Mohsin Shah");
}
